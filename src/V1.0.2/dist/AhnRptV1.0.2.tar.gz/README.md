안리포트 for Linux V1.0.2

지원 OS 범위: Ubuntu, Linux Mint 등의 Debian 계열 리눅스
* 차후 Fedora 계열 추가 예정

작동 방법
terminal에 ./AhnRpt 입력

결과물
AhnRpt<시간>.tar.gz
example: AhnRpt191113_175822.tar.gz

주의사항
압축을 푼 이후에 어느 파일도 손대지 말고 최대한 그대로 프로그램을 가동하시기 바랍니다.
AhnRpt와 sh파일이 있는 폴더에 다른 txt파일을 저장하지 마십시오.
프로그램 가동시 중간 결과물 정리를 위해 txt 파일을 삭제합니다.

AhnRpt For Linux V1.0.2
Supported OS: Ubuntu, Linux Mint
* Update to support Fedora and CentOS at further release.

How to run?
Simply type ./AhnRpt at terminal

Output
AhnRpt<Execution time>.tar.gz
example: AhnRpt191113_175822.tar.gz

Precautions
After you unzip the files, do not touch program file and folders for sh files
Do not save other txt files in the same folder. It will be removed during the program runs.
