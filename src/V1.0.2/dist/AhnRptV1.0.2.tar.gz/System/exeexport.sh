#!/bin/bash
export
