#!/bin/bash
env
