#!/bin/bash

filelist=`ls /etc/ssl/certs`

echo $filelist
