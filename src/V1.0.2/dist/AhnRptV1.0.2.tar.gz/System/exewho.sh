#!/bin/bash
uptime -s
who -r
