#!/bin/bash
export
